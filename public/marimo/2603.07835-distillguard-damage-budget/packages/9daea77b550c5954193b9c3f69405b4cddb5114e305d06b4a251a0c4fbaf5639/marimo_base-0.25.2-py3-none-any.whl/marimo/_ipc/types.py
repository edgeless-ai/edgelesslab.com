# Copyright 2026 Marimo. All rights reserved.
from __future__ import annotations

import msgspec
import msgspec.json

from marimo._ast.cell import CellConfig
from marimo._config.config import MarimoConfig
from marimo._messaging.msgspec_encoder import encode_json_bytes
from marimo._runtime.commands import AppMetadata
from marimo._runtime.virtual_file.storage import VirtualFileStorageType
from marimo._types.ids import CellId_t


class ConnectionInfo(msgspec.Struct):
    """ZeroMQ socket connection info."""

    control: int
    ui_element: int
    completion: int
    win32_interrupt: int | None

    input: int
    stream: int


class KernelArgs(msgspec.Struct):
    """Args to send to the kernel."""

    configs: dict[CellId_t, CellConfig]
    app_metadata: AppMetadata
    user_config: MarimoConfig
    log_level: int
    profile_path: str | None
    connection_info: ConnectionInfo
    # Whether to use run-mode config (autorun) vs edit-mode config (lazy)
    is_run_mode: bool = False
    redirect_console_to_browser: bool = True
    parent_pid: int | None = None
    # None means virtual files are unsupported and content is inlined as
    # data URLs -- required when no server is mounted to serve /@file/
    # (e.g. marimo-lsp). A server-managed kernel passes "shared_memory".
    # Unknown to older kernels, which ignore it and behave as None.
    virtual_file_storage: VirtualFileStorageType | None = None

    def encode_json(self) -> bytes:
        return encode_json_bytes(self)

    @classmethod
    def decode_json(cls, buf: bytes) -> KernelArgs:
        return msgspec.json.decode(buf, type=cls)
